namespace WebApplicationKol1.Service;

public class ChampionshipService
{
    
}